<?php
require 'db.php';

$title = $_POST['title'];
$category = $_POST['category'];
$id = $_POST['id'] ?? null;

$imageName = '';

if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
    $imageName = time() . '_' . basename($_FILES['image']['name']);
    $targetPath = 'uploads/' . $imageName;
    move_uploaded_file($_FILES['image']['tmp_name'], $targetPath);
}

// If ID exists => Update
if ($id) {
    if ($imageName) {
        $stmt = $conn->prepare("UPDATE items SET title=?, image=? WHERE id=?");
        $stmt->bind_param("ssi", $title, $imageName, $id);
    } else {
        $stmt = $conn->prepare("UPDATE items SET title=? WHERE id=?");
        $stmt->bind_param("si", $title, $id);
    }
} else {
    // Insert
    $stmt = $conn->prepare("INSERT INTO items (title, image, category) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $title, $imageName, $category);
}

$stmt->execute();
$stmt->close();
$conn->close();

echo "Success";
?>
