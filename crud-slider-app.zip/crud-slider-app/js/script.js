// js/script.js

let currentCategory = 'fruits'; // default tab

$(document).ready(function () {
  // Load default category
  loadItems(currentCategory);

  // Tab button click
  $('.tab-btn').click(function () {
    currentCategory = $(this).data('category');
    loadItems(currentCategory);
  });

  // Form submission (Add or Update)
  $('#item-form').submit(function (e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    formData.append('category', currentCategory);

    $.ajax({
      url: 'add_item.php',
      type: 'POST',
      data: formData,
      contentType: false,
      processData: false,
      success: function () {
        $('#item-form')[0].reset();
        $('#preview-image').attr('src', 'https://via.placeholder.com/300');
        $('#item-id').val('');
        loadItems(currentCategory);
      }
    });
  });

  // Image preview
  $('#item-image').change(function () {
    const file = this.files[0];
    if (file) {
      $('#preview-image').attr('src', URL.createObjectURL(file));
    }
  });

  // Cancel button
  $('#form-cancel').click(function () {
    $('#item-form')[0].reset();
    $('#item-id').val('');
    $('#preview-image').attr('src', 'https://via.placeholder.com/300');
  });
});

// Load items by category
function loadItems(category) {
  $.ajax({
    url: 'get_items.php',
    type: 'GET',
    data: { category },
    success: function (data) {
      $('#slider-box').html(data);
    }
  });
}

// Called when "Edit" button is clicked
function editItem(id, title, image) {
  $('#item-id').val(id);
  $('#item-title').val(title);
  $('#preview-image').attr('src', 'uploads/' + image);
}

// Called when "Delete" button is clicked
function deleteItem(id) {
  if (confirm("Are you sure you want to delete this item?")) {
    $.ajax({
      url: 'delete_item.php',
      type: 'POST',
      data: { id },
      success: function () {
        loadItems(currentCategory);
      }
    });
  }
}
