<?php
require 'db.php';

$category = $_GET['category'];
$stmt = $conn->prepare("SELECT * FROM items WHERE category = ?");
$stmt->bind_param("s", $category);
$stmt->execute();

$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    echo '<div class="item-card">';
    echo '<img src="uploads/' . $row['image'] . '" alt="Item Image">';
    echo '<h4>' . htmlspecialchars($row['title']) . '</h4>';
    echo '<button class="btn btn-sm btn-info" onclick="editItem(' . $row['id'] . ', \'' . addslashes($row['title']) . '\', \'' . $row['image'] . '\')">Edit</button> ';
    echo '<button class="btn btn-sm btn-danger" onclick="deleteItem(' . $row['id'] . ')">Delete</button>';
    echo '</div>';
}

$stmt->close();
$conn->close();
?>
